#!/bin/bash

echo "=== Startup: $(date) ==="
echo "=== Working dir: $(pwd) ==="

# Activate Oryx-built virtual environment if present
if [ -d "/antenv" ]; then
    echo "=== Activating /antenv ==="
    source /antenv/bin/activate
fi

export PYTHONPATH=/home/site/wwwroot:$PYTHONPATH

echo "=== Running migrations (60s timeout) ==="
timeout 60 python manage.py migrate --no-input 2>&1 || echo "WARNING: migrate failed or timed out — starting gunicorn anyway"

echo "=== Seeding event sources (idempotent) ==="
timeout 30 python manage.py seed_event_sources 2>&1 || echo "WARNING: seed_event_sources failed"

echo "=== Populating states (idempotent — adds Idaho & Arkansas if missing) ==="
timeout 30 python manage.py populate_states 2>&1 || echo "WARNING: populate_states failed"

echo "=== Populating Springfield cities (idempotent) ==="
timeout 30 python manage.py populate_springfields 2>&1 || echo "WARNING: populate_springfields failed"

echo "=== Starting Gunicorn ==="
exec gunicorn \
  --workers 2 \
  --threads 2 \
  --timeout 120 \
  --bind 0.0.0.0:8000 \
  --access-logfile '-' \
  --error-logfile '-' \
  mocon.wsgi:application
